#pragma once
#include "Employee.h"
using namespace std;

//Constructors
Employee::Employee()
{
	name = "";
	wait_time = 0;
	retain_time = 0;
}

Employee::Employee(string n)
{
	name = n;
	wait_time = 0;
	retain_time = 0;
}

//getters
string Employee::get_name()
{
	return name;
}

int Employee::get_wait_time()
{
	return wait_time;
}

int Employee::get_retain_time()
{
	return retain_time;
}

//Setters
void Employee::set_name(string n)
{
	name = n;
}

void Employee::set_wait_time(int t)
{
	wait_time = t;
}

void Employee::set_retain_time(int t)
{
	retain_time = t;
}

//Functions
bool operator<(const Employee& lhs, const Employee& rhs)
{
	return((lhs.wait_time - lhs.retain_time) < (rhs.wait_time - rhs.retain_time));
}