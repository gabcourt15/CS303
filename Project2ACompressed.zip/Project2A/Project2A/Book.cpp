#include "Book.h"
using namespace std;

//Constructors
Book::Book()
{
	return;
}

Book::Book(string n)
{
	name = n;
}

Book::Book(string book_name, Date checkout)
{
	name = book_name;
	checkout_date = checkout;
}

Book::Book(const Book& other)
{
	name = other.name;
	checkout_date = other.checkout_date;
	checkin_date = other.checkin_date;
	employees = other.employees;
	archived = other.archived;
}

//Getters
string Book::get_name()
{
	return name;
}

Date Book::get_checkout_day()
{
	return checkout_date;
}

Date Book::get_checkin_day()
{
	return checkin_date;
}

Date Book::get_last_retained_date()
{
	return last;
}

bool Book::get_archived()
{
	return archived;
}

//Setters
void Book::set_name(string n)
{
	name = n;
}

void Book::set_checkout_day(Date d)
{
	checkout_date = last = d;
}

void Book::set_checkin_day(Date d)
{
	checkin_date = d;
}

void Book::set_archived(bool b)
{
	archived = b;
}

void Book::set_last_retained_date(Date d)
{
	last = d;
}

//Functions
Employee* Book::pop()
{
	return employees.pop();
}

Employee* Book::top()
{
	return employees.top();
}

bool Book::is_empty()
{
	return employees.is_empty();
}

void Book::fill_queue(const list<Employee*> employee_list)
{
	list<Employee*>::const_iterator itr;
	for (itr = employee_list.begin(); itr != employee_list.end(); itr++)
	{
		employees.add_employee(*itr);
	}
}

