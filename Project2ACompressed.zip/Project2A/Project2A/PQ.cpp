#pragma once
#include"PQ.h"
using namespace std;

//Constructor
PQ::PQ()
{
	return;
}

//Functions
bool PQ::is_empty()
{
	return book_queue.size() < 1;
}

Employee* PQ::top()
{
	Employee *max = *book_queue.begin();
	vector<Employee*>::iterator itr = book_queue.begin();
	itr++;
	for (itr; itr != book_queue.end(); itr++)
	{
		if ((max->get_wait_time() - max->get_retain_time()) < ((*itr)->get_wait_time() - (*itr)->get_retain_time()))
		{
			max = *itr;
		}
	}
	return max;
}

Employee* PQ::pop()
{
	Employee* max = *book_queue.begin();
	vector<Employee*>::iterator itr, toErase;
	itr = toErase = book_queue.begin();
	itr++;
	for (itr; itr != book_queue.end(); itr++)
	{
		if ((max->get_wait_time() - max->get_retain_time()) < ((*itr)->get_wait_time() - (*itr)->get_retain_time()))
		{
			max = *itr;
			toErase = itr;
		}
	}
	book_queue.erase(toErase);
	return max;
}

void PQ::add_employee(Employee* e)
{
	book_queue.push_back(e);
}
