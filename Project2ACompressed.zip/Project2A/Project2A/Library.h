#pragma once

#include <stdio.h>
#include<iostream>
#include<string>
#include<queue>
#include<list>
#include"Book.h"
#include"Employee.h"
#include "Date.h"
using namespace std;

class Library {
public:
	//Constructor
	Library();
	//Deconstructor
	~Library();
	//Functions
	void pass_book(string b, Date d);
	void circulate_book(string b, Date d);
	void add_employee(string n);
	void add_book(string b);
private:
	list<Book> checked_out_books;
	list<Book> archived_books;
	list<Employee*> emp_list;

};
