#pragma once
#include"Library.h"
using namespace std;

//Constructor
Library::Library()
{
	return;
}

//Deconstructor
Library::~Library()
{
	list<Employee*>::iterator itr;
	for (itr = emp_list.begin(); itr != emp_list.end(); itr++)
	{
		delete *itr;
	}
}

//Functions
void Library::pass_book(string b, Date d)
{
	Employee *next, *prev;
	list<Book>::iterator itr;
	for (itr = checked_out_books.begin(); itr != checked_out_books.end(); itr++)
	{
		if (itr->get_name() == b)
		{
			prev = itr->pop();
			prev->set_retain_time(d - itr->get_last_retained_date());
			if (!itr->is_empty())
			{
				next = itr->top();
				next->set_wait_time(d - itr->get_checkout_day());
				itr->set_last_retained_date(d);
			}
			else
			{
				itr->set_archived(true);
				itr->set_checkin_day(d);
				archived_books.push_back(*itr);
				checked_out_books.erase(itr);
			}
			break;
		}
	}
}

void Library::circulate_book(string b, Date d)
{
	list<Book>::iterator itr;
	for (itr = checked_out_books.begin(); itr != checked_out_books.end(); itr++)
	{
		if (itr->get_name() == b)
		{
			itr->fill_queue(emp_list);
			itr->set_checkout_day(d);
			break;
		}
	}
}

void Library::add_book(string b)
{
	Book book(b);
	checked_out_books.push_back(book);
}

void Library::add_employee(string n)
{
	Employee *e;
	e = new Employee(n);
	emp_list.push_front(e);
}