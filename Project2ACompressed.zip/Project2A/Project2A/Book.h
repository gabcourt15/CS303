#pragma once

#include <stdio.h>
#include<string>
#include <list>
#include "PQ.h"
#include "Date.h"
#include"Employee.h"
using namespace std;

class Book {
public:
	//Constructors
	Book();
	Book(string book_name);
	Book(string book_name, Date checkout);
	Book(const Book& other);
	//Getters
	string get_name();
	Date get_checkout_day();
	Date get_checkin_day();
	Date get_last_retained_date();
	bool get_archived();
	//Setters
	void set_name(string n);
	void set_checkout_day(Date d);
	void set_checkin_day(Date d);
	void set_archived(bool b); 
	void set_retain_time(Date d);
	void set_last_retained_date(Date d);
	//Functions
	Employee* pop();
	Employee* top();
	bool is_empty();
	void fill_queue(list<Employee*> employee_list);
private:
	string name;
	Date checkout_date;
	Date checkin_date;
	bool archived;
	PQ employees;
	Date last;
};
