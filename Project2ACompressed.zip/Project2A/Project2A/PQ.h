#pragma once
#include<stdio.h>
#include<list>
#include<vector>
#include<iostream>
#include"Employee.h"
using namespace std;

class PQ {
public:
	//Constructor
	PQ();
	//Functions
	bool is_empty();
	Employee* top();
	Employee* pop();
	void add_employee(Employee* e);
private:
	vector<Employee*> book_queue;
};
