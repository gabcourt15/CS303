#include"Book.h"
#include"Employee.h"
#include"Library.h"
#include<iostream>
#include<queue>
#include<list>
using namespace std;

void main()
{
	Library l;
	
	l.add_book("Software Engineering");
	l.add_book("Chemistry");

	l.add_employee("Adam");
	l.add_employee("Sam");
	l.add_employee("Ann");

	l.circulate_book("Chemistry", Date(2015, 3, 1, DateFormat::US));
	l.circulate_book("Software Engineering", Date(2015, 4, 1, DateFormat::US));
	l.pass_book("Chemistry", Date(2015, 3, 5, DateFormat::US));
	l.pass_book("Chemistry", Date(2015, 3, 7, DateFormat::US));
	l.pass_book("Chemistry", Date(2015, 3, 15, DateFormat::US));

	l.pass_book("Software Engineering", Date(2015, 4, 5, DateFormat::US));
	l.pass_book("Software Engineering", Date(2015, 4, 10, DateFormat::US));
	l.pass_book("Software Engineering", Date(2015, 4, 15, DateFormat::US));
}