#pragma once

#include <stdio.h>
#include <string>
#include "Date.h"
using namespace std;

class Employee {
public:
	//Constructors
	Employee();
	Employee(string n);
	//Getters
	string get_name();
	int get_wait_time();
	int get_retain_time();
	//Setters
	void set_name(string n);
	void set_wait_time(int t);
	void set_retain_time(int t);
	//Functions
	friend bool operator<(const Employee& lhs, const Employee& rhs);
private:
	string name;
	int wait_time;
	int retain_time;
};
