#include "MorseCode.h"
#include <fstream>
#include <iostream>
using namespace std;

void main()
{
	//open file that contains letters and morsecode equivalents
	ifstream conversionFile("morse.txt");
	//create morse code tree
	MorseCode m;
	//create storage variables
	char l; //letter
	string mc; //morse code 
	string line; //line from text file

				 //reding in file to add letters to the mctree
	while (!conversionFile.fail())
	{
		conversionFile >> line;
		for (int i = 0; i <= line.size(); i++)
		{
			if (isalpha(line[i])) //if letter
				l = line[i]; //store in letter variable
			else //if anything other than a letter
				mc += line[i]; //store in morse code
		}
		m.addLetterToTree(l, mc);
		mc = "";
	}
	string storage = "ac";
	cout << storage << endl;
	cout << m.encrypt(storage);
	system("Pause");
	storage = ".- -.-. ";
	cout << m.decrypt(storage);

}
