#pragma once

#include<iostream>
#include<fstream>
#include<map>
#include<vector>
#include<string>

using namespace std;

struct MCTree {
	//Constructor
	MCTree();

	string letter;
	string morsecode;
	MCTree *l; //left subtree pointer
	MCTree *r; //right subtree pointer
};

class MorseCode {
public:
	//Constructor
	MorseCode();

	//Functions
	string getLetter(string mc); //gets letter from morse code string
	string encrypt(string word); //translates word from english to morse code
	string decrypt(string mc); //translates morsecode to english
	void addLetterToTree(char letterToAdd, string mc); //adds english letter to morse code tree
private:
	map<char, string> conversionMap;
	MCTree *root;

};