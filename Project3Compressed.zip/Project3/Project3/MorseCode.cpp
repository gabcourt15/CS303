#include"MorseCode.h"
using namespace std;

MorseCode::MorseCode()
{
	root = new MCTree; //creates new morsecode tree
	root->letter = ""; //sets the letter to empty string
	root->morsecode = "NULL"; //sets the morse code to string null
	root->l = NULL; //sets the left subtree to point to null
	root->r = NULL; //sets the right subtree to point to null
}

string MorseCode::getLetter(string mc)
{
	MCTree *currentNode = root;
	for (int i = 0; i < mc.length(); i++) //for symbol in the string
	{
		if (currentNode == NULL)
		{
			cout << "The tree is empty...";
		}
		if (mc[i] == '.') //if the symbol is a .
		{
			currentNode = currentNode->l;
		}
		else //if the symbol is a -
		{
			currentNode = currentNode->r;
		}
	}
	return currentNode->letter;
}

string MorseCode::encrypt(string word)
{
	string message;
	for (int i = 0; i < word.length(); i++)//for letter in word
	{
		message += conversionMap[word[i]]; //add morse code to message from map
	}
	message.pop_back();
	return string(message);
}

string MorseCode::decrypt(string mc)
{
	string message;
	while (!mc.empty())//while there is morse code to read
	{
		string submc = mc.substr(0, mc.find(" ")); //make substring of first morse code symbol
		message += getLetter(submc); //find the corresponding letter to that symbol and add to message
		mc.erase(0, mc.find_first_of(" ") + 1); //erase substring from morse code string
	}
	return message;
}

void MorseCode::addLetterToTree(char letterToAdd, string mc)
{
	conversionMap[letterToAdd] = mc; //add to map
	MCTree *currentNode = root; //start at root
	for (int i = 0; i <= mc.length(); i++) //for lenght of morsecode string
	{
		if (mc[i] == '.')//do we need to go left?
		{
			if (currentNode->l == NULL) //is there another node?
			{
				currentNode->l = new MCTree;
				currentNode = currentNode->l;
			}
			else
			{
				currentNode = currentNode->l;
			}
		}
		else if (mc[i] == '-' || mc[i] == '_')//do we need to go right?
		{
			if (currentNode->r == NULL)//is there another node?
			{
				currentNode->r = new MCTree;
				currentNode = currentNode->r;
			}
			else
			{
				currentNode = currentNode->r;
			}
		}
	}
	currentNode->morsecode = mc; //add the data to the node
	currentNode->letter = letterToAdd;//add the data to the node
}

MCTree::MCTree()
{
	l = NULL;
	r = NULL;
}



